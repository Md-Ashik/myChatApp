
package chat;

/**
 *
 * @author Md Ashik
 */
public class Chat {   
    public static void main(String[] args) {
    }
    
}
